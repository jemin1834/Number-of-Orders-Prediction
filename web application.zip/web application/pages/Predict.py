import streamlit as st
import pandas as pd
import joblib
import sqlite3
from datetime import datetime
from io import StringIO

st.set_page_config(page_title="Orders App", page_icon="🛒", layout="centered")

# Load model
model = joblib.load('order_predictor_model.pkl')

st.title("🛒 Prediction of Number of Orders")

st.markdown("""
This app predicts the **number of orders** for a store based on:
- Store type
- Location
- Region code
- Discount type
- Date-related features
""")

st.sidebar.header("📥 Input Store Data")

def user_input_features():
    store_type = st.sidebar.selectbox('Store Type', [0, 1, 2, 3])
    location_type = st.sidebar.selectbox('Location Type', [0, 1, 2])
    region_code = st.sidebar.selectbox('Region Code', list(range(0, 53)))
    discount = st.sidebar.selectbox('Discount', [0, 1])
    date = st.sidebar.date_input("Week Start Date", datetime(2022, 1, 1))

    year = date.year
    month = date.month
    day = date.day
    week = date.isocalendar()[1]

    data = {
        'Store_id': 0,
        'Store_Type': store_type,
        'Location_Type': location_type,
        'Region_Code': region_code,
        'Holiday': 0,
        'Discount': discount,
        'Sales': 0,
        'year': year,
        'month': month,
        'day': day,
        'week': week
    }

    return pd.DataFrame(data, index=[0]), date

input_df, selected_date = user_input_features()

st.subheader('🧾 Input Data')
st.write(input_df)

# Prediction
prediction = model.predict(input_df)
predicted_orders = int(prediction[0])
st.subheader('📈 Predicted Number of Orders')
st.success(f"Estimated Orders: {predicted_orders}")

# Save and download section
if st.button("💾 Save Prediction"):
    input_df['Predicted_Orders'] = predicted_orders
    input_df['Prediction_Timestamp'] = datetime.now()

    # Save to SQLite
    conn = sqlite3.connect("orders_app.db")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS Predictions (
            Store_id INTEGER,
            Store_Type INTEGER,
            Location_Type INTEGER,
            Region_Code INTEGER,
            Holiday INTEGER,
            Discount INTEGER,
            Sales INTEGER,
            year INTEGER,
            month INTEGER,
            day INTEGER,
            week INTEGER,
            Predicted_Orders INTEGER,
            Prediction_Timestamp TEXT
        );
    """)
    input_df.to_sql("Predictions", conn, if_exists='append', index=False)
    conn.commit()
    conn.close()
    st.success("✅ Prediction saved to database!")

    # CSV download
    csv = input_df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Download Prediction as CSV",
        data=csv,
        file_name=f'order_prediction_{selected_date}.csv',
        mime='text/csv'
    )

# View recent predictions
st.markdown("---")
st.subheader("🕓 Recent Predictions")
try:
    conn = sqlite3.connect("orders_app.db")
    df_recent = pd.read_sql(
        "SELECT * FROM Predictions ORDER BY Prediction_Timestamp DESC LIMIT 5", conn)
    conn.close()
    if not df_recent.empty:
        st.dataframe(df_recent)
    else:
        st.info("No previous predictions found.")
except Exception as e:
    st.error(f"Error reading from database: {e}")
