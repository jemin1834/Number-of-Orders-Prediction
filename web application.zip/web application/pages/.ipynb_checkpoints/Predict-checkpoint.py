import streamlit as st
import pandas as pd
import joblib
from datetime import datetime

st.set_page_config(page_title="Prediction of Number of Orders", page_icon="🛒")

model = joblib.load('order_predictor_model.pkl')

st.title("🛒 Prediction of Number of Orders")

st.markdown("""
This app predicts the **number of orders** for a store based on:
- Store type
- Location
- Region code
- Discount type
- Date-related features
""")

st.sidebar.header("📥 Input Store Data")

def user_input_features():
    store_type = st.sidebar.selectbox('Store Type', [0, 1, 2, 3])
    location_type = st.sidebar.selectbox('Location Type', [0, 1, 2])
    region_code = st.sidebar.selectbox('Region Code', list(range(0, 53)))
    discount = st.sidebar.selectbox('Discount', [0, 1])
    date = st.sidebar.date_input("Week Start Date", datetime(2022, 1, 1))

    year = date.year
    month = date.month
    day = date.day
    week = date.isocalendar()[1]

    data = {
        'Store_id': 0,
        'Store_Type': store_type,
        'Location_Type': location_type,
        'Region_Code': region_code,
        'Holiday': 0,
        'Discount': discount,
        'Sales': 0,
        'year': year,
        'month': month,
        'day': day,
        'week': week
    }

    return pd.DataFrame(data, index=[0])

input_df = user_input_features()

st.subheader('🧾 Input Data')
st.write(input_df)

prediction = model.predict(input_df)
st.subheader('📈 Predicted Number of Orders')
st.success(f"Estimated Orders: {int(prediction[0])}")
