import streamlit as st

st.set_page_config(page_title="Login", page_icon="🔐")
st.title("🔐 Login Page")

st.text_input("Username")
st.text_input("Password", type="password")
st.button("Login")
