import streamlit as st

st.set_page_config(page_title="About", page_icon="ℹ️")
st.title("ℹ️ About Us")

st.markdown("""
This app was created to help store managers and analysts predict orders using historical and categorical store data.
""")
