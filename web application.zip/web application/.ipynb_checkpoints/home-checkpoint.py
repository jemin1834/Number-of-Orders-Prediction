import streamlit as st

st.set_page_config(page_title="Home", page_icon="🏠")
st.title("🏠 Welcome to the Orders Prediction App")
st.markdown("""
Use the sidebar to navigate:
- 📈 Predict Orders
- 🔐 Login/Register
- 👨‍💼 Admin Dashboard
- ℹ️ About Us
""")
